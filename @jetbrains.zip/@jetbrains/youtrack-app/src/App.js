import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
function App() {
    return (_jsx("div", { className: "App", children: _jsxs("header", { className: "App-header", children: [_jsxs("p", { children: ["Edit ", _jsx("code", { children: "src/App.tsx" }), " and save to reload."] }), _jsx("a", { className: "App-link", href: "https://reactjs.org", target: "_blank", rel: "noopener noreferrer", children: "Learn React" })] }) }));
}
export default App;
